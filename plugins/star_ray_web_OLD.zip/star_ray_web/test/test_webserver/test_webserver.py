# pylint: disable=E0401, E0611,
from star_ray.plugin.web import WebServer

webserver = WebServer()
