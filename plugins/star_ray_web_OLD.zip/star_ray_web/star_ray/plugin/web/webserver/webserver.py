# pylint: disable=E1101
from collections import defaultdict
from queue import Queue
import ray
from fastapi import FastAPI, WebSocket, Depends, HTTPException, WebSocketDisconnect
from ray import serve
from ray.actor import ActorHandle

from star_ray.agent import Agent, AgentFactory
from star_ray.environment.ambient import Ambient
from star_ray.environment.environment import Environment

from star_ray.typing import Event

import asyncio
from importlib.resources import files
import logging
from typing import Any, Dict, List, Tuple

from fastapi import FastAPI, Request, WebSocket
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates

from ray import serve
from ray.serve.schema import LoggingConfig

from star_ray.event import (
    VisibilityEvent,
    MouseButtonEvent,
    MouseMotionEvent,
)

from .auth import authenticate_user

ROUTE_MOUSE_BUTTON = "on_mouse_button"
ROUTE_MOUSE_MOTION = "on_mouse_motion"
ROUTE_VISIBILITY_CHANGE = "on_visibility_change"


def get_default_template_data():
    """Gets the default Jinja2 template data for use with star_ray_web/static/templates/index.html.jinja

    Returns:
        Dict[str, Any]: default template data

    Usage Example:
    ```
    from ray import serve
    from star_ray_web import WebServer, get_default_template_data
    serve.start(http_options={"port": 8888})
    webserver = serve.run(WebServer.bind(template_data=get_default_template_data()))
    ```
    """
    return dict(
        handle_mouse_button=dict(
            post_route=ROUTE_MOUSE_BUTTON,
            disable_context_menu=True,
        ),
        handle_mouse_motion=dict(
            post_route=ROUTE_MOUSE_MOTION,
        ),
        handle_visibility=dict(post_route=ROUTE_VISIBILITY_CHANGE),
        head="",
        body="",
    )


# fastapi app - this is globally defined singleton that is used by WebServer
app = FastAPI()


WS_TRY_AGAIN = 1013

from abc import abstractmethod


class WebAvatar(Agent):

    def __init__(self, sensors, actuators, *args, **kwargs):
        super().__init__(sensors, actuators, *args, **kwargs)

    @abstractmethod
    async def receive(self, data: bytes):
        pass
        # data should be converted to actions and "attempted" in the relevant actuators.

    @abstractmethod
    async def send(self, ambient: Ambient) -> bytes:
        pass
        # data from sensors should be retrieved and returned when it is available.
        # Typically the observation data should be awaited - dont repeatedly return if there are no new observations.


@serve.deployment(
    num_replicas=1,
)
@serve.ingress(app)
class WebServer:
    # NOTE the webserver must be part of the Ambient ray actor, this drastically simplifies management of avatars and does not come with a significant performance cost since most avatar operations are aysnchronous (IO bound) and act on the ambient anyway.

    def __init__(self, ambient: Ambient, avatar_factory: AgentFactory, *args, **kwargs):
        super().__init__(self, *args, **kwargs)
        self._ambient: Ambient = ambient
        self._avatar_factory = avatar_factory
        self._open_connections = defaultdict(bool)

    @app.websocket("/{token}")
    async def websocket_endpoint(self, websocket: WebSocket, token: str):

        user_id = await authenticate_user(token)
        if not user_id:
            await websocket.close(code=1008)
            return
        await websocket.accept()
        self._open_connections[user_id] = True
        # create avatar using the the factory provided
        user_agent = self._avatar_factory(user_id)
        assert isinstance(user_agent, WebAvatar)  # some methods are required...
        # add the avatar to the environment (ambient)
        self._ambient.add_agent(user_agent)

        # Task for receiving data
        receive_task = asyncio.create_task(receive_data(websocket, user_agent))

        # Task for sending data
        send_task = asyncio.create_task(send_data(websocket, user_agent))

        # Wait for either task to finish (e.g., due to WebSocketDisconnect)
        _, pending = await asyncio.wait(
            [receive_task, send_task], return_when=asyncio.FIRST_COMPLETED
        )

        # Cancel any pending tasks to clean up
        for task in pending:
            task.cancel()

        self._open_connections[user_id] = False
        self._ambient.remove_agent(user_agent)
        print(f"WebSocket disconnected for user {user_id}")


async def receive_data(websocket: WebSocket, user_agent: WebAvatar):
    try:
        while True:
            data = await websocket.receive_bytes()
            await user_agent.receive(data)
    except WebSocketDisconnect:
        pass


async def send_data(websocket: WebSocket, user_agent: WebAvatar):
    try:
        while True:
            data = await user_agent.send()
            await websocket.send_bytes(data)
    except WebSocketDisconnect:
        pass


# @serve.deployment(
#     num_replicas=1,
#     logging_config=LoggingConfig(enable_access_log=False, log_level="WARNING"),
# )
# @serve.ingress(app)
# class WebServer:
#     def __init__(
#         self,
#         *args: Tuple[Any, ...],
#         template_path: str = None,
#         template_data: Dict[str, str] = None,
#         **kwargs: Dict[str, Any],
#     ):
#         # need to give self to super().__init__ due to decorators... it looks a bit weird I know...
#         super().__init__(self, *args, **kwargs)
#         self._logger = logging.getLogger("ray.serve")
#         self._socket_handlers = {}
#         self._templates_path = (
#             str(files(__package__).joinpath("static"))
#             if template_path is None
#             else template_path
#         )
#         self._template_data = dict() if template_data is None else template_data
#         self._event_buffer = _EventBuffer(maxsize=EVENT_BUFFER_MAX_SIZE)

#     @app.get("/", response_class=HTMLResponse)
#     async def index(self, request: Request) -> str:
#         # in line javascript to avoid static file caching issues after modification
#         templates = Jinja2Templates(directory=self._templates_path)
#         response = templates.TemplateResponse(
#             "templates/index.html.jinja",
#             {"request": request, **self._template_data},
#         )
#         return response

#     @app.post(f"/{ROUTE_MOUSE_BUTTON}")
#     async def on_mouse_button(self, request: Request) -> str:
#         try:
#             data = await request.json()
#             position = (data["position"]["x"], data["position"]["y"])
#             button = data["button"]
#             status = MouseButtonEvent.status_from_string(data["status"])
#             target = data["id"]
#             target = target if len(target) > 0 else None
#             await self._add_event(
#                 MouseButtonEvent.new(
#                     source=request.client.host,
#                     button=button,
#                     position=position,
#                     status=status,
#                     target=target,
#                 )
#             )
#             return JSONResponse(content={})
#         except Exception as e:
#             self._logger.exception("Invalid post request.")
#             return JSONResponse(content={"error": str(e)}, status_code=500)

#     @app.post("/on_mouse_motion")
#     async def on_mouse_motion(self, request: Request) -> str:
#         try:
#             data = await request.json()
#             position = (data["position"]["x"], data["position"]["y"])
#             relative = (data["relative"]["x"], data["relative"]["y"])
#             target = data["id"]
#             target = target if len(target) > 0 else None
#             await self._add_event(
#                 MouseMotionEvent.new(
#                     source=request.client.host,
#                     position=position,
#                     relative=relative,
#                     target=target,
#                 )
#             )
#             return JSONResponse(content={})
#         except Exception as e:
#             self._logger.exception("Invalid post request.")
#             return JSONResponse(content={"error": str(e)}, status_code=500)

#     @app.post(f"/{ROUTE_VISIBILITY_CHANGE}")
#     async def on_visibility_change(self, request: Request) -> str:
#         try:
#             data = await request.json()
#             if data["visibility"] == "visible":
#                 # trigger an event
#                 await self._add_event(
#                     VisibilityEvent.new_visible(source=request.client.host)
#                 )
#             elif data["visibility"] == "hidden":
#                 await self._add_event(
#                     VisibilityEvent.new_hidden(source=request.client.host)
#                 )
#             else:
#                 raise ValueError(
#                     f"Invalid value for `visibility` {data['visibility']}, valid values include: [`visible`, `hidden`]"
#                 )
#             return JSONResponse(content={})
#         except Exception as e:
#             self._logger.exception("Invalid post request.")
#             return JSONResponse(content={"error": str(e)}, status_code=500)

#     @app.websocket("/{route_id}")
#     async def _websocket_router(self, websocket: WebSocket, route_id: str):
#         if not route_id in self._socket_handlers.keys():
#             await websocket.close(
#                 code=WS_TRY_AGAIN
#             )  # close the connect and request that the client tries to connect again
#             raise MissingWebSocketHandler(route_id)
#         await self._socket_handlers[route_id].open(websocket)

#     def add_web_socket_handler(
#         self, route, replace=False, socket_handler: WebSocketHandler = None
#     ):
#         if not replace and route in self._socket_handlers:
#             raise ValueError(f"socket handler already exists for route: {route}.")
#         else:
#             socket_handler = WebSocketHandler(route)
#             self._socket_handlers[route] = socket_handler

#     def update_socket(self, route, message):
#         self._socket_handlers[route].update(message)

#     async def _add_event(self, event):
#         await self._event_buffer.put(event)

#     def get_events(self):
#         # this should be called remotely to pop from the event queue.
#         return self._event_buffer.get_all_nowait()
